package com.kopo.jingyu;

public class Worker {
	int idx;
	String name;
	String sex;
	String address;
	String part;
	
	Worker(){
		
	}
	Worker(int idx, String name, String sex, String address, String part){
		this.name = name;
		this.sex = sex;
		this.address = address;
		this.part = part;
	}

}
